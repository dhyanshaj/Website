export const BUSINESS = Object.freeze({ name: 'Deepa Steel', phone: '919322758844', email: 'deepasteel1@gmail.com' });
export const CATALOG = [
  { id: 'structural', name: 'Structural sections', short: 'Sections for your project requirements, sourced to the specification you share.', spec: 'ISA · ISMC · ISMB · NPB · UB · UC · WPB' },
  { id: 'plates', name: 'Mild steel plates', short: 'Specify your thickness, dimensions and quantity. We’ll take it from there.', spec: 'Thickness: 3–50 mm' },
  { id: 'tmt', name: 'TMT bars', short: 'Share the diameter and grade required for your construction project.', spec: 'Sizes & grades confirmed on enquiry' },
  { id: 'rounds', name: 'Round bars', short: 'A range of diameters to match your material list and project needs.', spec: 'Diameter: 6–100 mm' },
  { id: 'pipes', name: 'Pipes', short: 'Round, square or rectangular. Tell us the dimensions and wall thickness you need.', spec: 'Round · Square · Rectangular' },
];
export const SECTIONS = ['ISA', 'ISMC', 'ISMB', 'NPB', 'UB', 'UC', 'WPB'];
export const UNITS = ['tonnes', 'kg', 'pieces'];
export const MAX_ITEMS = 10;
export const MAX_FILES = 3;
export const MAX_FILE_BYTES = 10 * 1024 * 1024;
const number = value => value !== '' && value != null && Number.isFinite(Number(value)) && Number(value) > 0;
export function escapeHTML(value = '') { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]); }
export function categoryName(id) { return CATALOG.find(category => category.id === id)?.name || 'Steel'; }
export function validateItem(item) {
  const errors = [];
  if (!CATALOG.some(category => category.id === item.category)) errors.push('Choose a product category.');
  if (!number(item.quantity) || Number(item.quantity) > 100000000) errors.push('Enter a quantity greater than zero (up to 100,000,000).');
  if (!UNITS.includes(item.unit)) errors.push('Choose tonnes, kg or pieces.');
  if (item.assistance && !item.description?.trim()) errors.push('Describe what you need so we can help with the specifications.');
  const requireNumber = (key, label, min = 0, max = Infinity) => {
    const value = item[key];
    if (item.assistance && (value == null || value === '')) return;
    if (!number(value) || Number(value) < min || Number(value) > max) errors.push(min && Number.isFinite(max) ? `${label} must be between ${min} and ${max} mm.` : `Enter a valid ${label.toLowerCase()} in mm.`);
  };
  if (item.category === 'structural' && !item.assistance) {
    if (!SECTIONS.includes(item.section)) errors.push('Select a structural section.');
    if (!item.designation?.trim()) errors.push('Enter a section designation or dimensions.');
  }
  if (item.category === 'plates') { requireNumber('thickness', 'Plate thickness', 3, 50); requireNumber('width', 'Width'); }
  if (item.category === 'rounds') requireNumber('diameter', 'Round bar diameter', 6, 100);
  if (item.category === 'tmt') requireNumber('diameter', 'TMT diameter');
  if (item.category === 'pipes') {
    if (!['round', 'square', 'rectangular'].includes(item.shape) && !item.assistance) errors.push('Choose a pipe shape.');
    if (item.shape === 'round') requireNumber('diameter', 'Outer diameter');
    if (['square', 'rectangular'].includes(item.shape)) requireNumber('width', 'Outer width');
    if (item.shape === 'rectangular') requireNumber('height', 'Outer height');
    requireNumber('thickness', 'Wall thickness');
    const outer = item.shape === 'round' ? Number(item.diameter) : Math.min(Number(item.width), item.shape === 'rectangular' ? Number(item.height) : Infinity);
    if (outer > 0 && Number(item.thickness) * 2 >= outer) errors.push('Pipe wall thickness must be less than half the smallest outer dimension.');
  }
  requireNumber('length', 'Length');
  if (item.unit === 'pieces' && number(item.quantity) && !Number.isInteger(Number(item.quantity))) errors.push('Enter a whole number of pieces.');
  return errors;
}
export function itemSpecs(item) {
  const parts = [];
  if (item.section) parts.push(item.section);
  if (item.designation) parts.push(item.designation);
  if (item.shape) parts.push(`${item.shape[0].toUpperCase()}${item.shape.slice(1)} pipe`);
  for (const [key, label] of [['thickness', item.category === 'pipes' ? 'Wall' : 'Thickness'], ['diameter', item.category === 'pipes' ? 'Outer diameter' : 'Diameter'], ['width', 'Width'], ['height', 'Height'], ['length', 'Length']]) {
    if (item[key]) parts.push(`${label}: ${item[key]} mm`);
  }
  if (item.grade) parts.push(`Grade: ${item.grade}`);
  if (item.assistance) parts.push(`Specification help requested: ${item.description}`);
  return parts.join(' · ');
}
export function orderWeight(items) {
  return {
    knownTonnes: items.reduce((sum, item) => sum + (item.unit === 'tonnes' ? Number(item.quantity) : item.unit === 'kg' ? Number(item.quantity) / 1000 : 0), 0),
    needsEstimate: items.some(item => item.unit === 'pieces'),
  };
}
export function formatWeight(weight) { return Number(weight.toFixed(3)).toLocaleString('en-IN', { maximumFractionDigits: 3 }); }
export function validateDetails(details, items) {
  const errors = [];
  if (!items.length) errors.push('Add at least one product.');
  if (!details.name?.trim()) errors.push('Enter your name.');
  if (!['WhatsApp', 'Phone call', 'Email'].includes(details.reply)) errors.push('Choose how we should reply.');
  if (details.reply === 'Email') {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(details.email || '')) errors.push('Enter a valid email address for our reply.');
  } else {
    const digits = (details.phone || '').replace(/\D/g, '');
    if (!/^[+\d\s().-]+$/.test(details.phone || '') || digits.length < 7 || digits.length > 15) errors.push('Enter a valid contact number, including the country code where needed.');
  }
  if (!details.location?.trim()) errors.push('Enter the delivery city and state.');
  if (details.pincode && !/^\d{6}$/.test(details.pincode)) errors.push('Enter a six-digit Indian delivery PIN code, or leave it blank.');
  if (!['Truck', 'Tailor', 'Help me choose'].includes(details.transport)) errors.push('Choose a dispatch option.');
  const { knownTonnes, needsEstimate } = orderWeight(items);
  const minimum = details.transport === 'Tailor' ? 40 : 10;
  if (needsEstimate) {
    if (!number(details.estimatedTonnes) || Number(details.estimatedTonnes) < minimum) errors.push(`For quantities in pieces, enter your estimated total order weight of at least ${minimum} tonnes. We will confirm it; pieces are not automatically converted to weight.`);
    else if (Number(details.estimatedTonnes) < knownTonnes) errors.push('Your total weight estimate cannot be less than the products already entered by weight.');
  } else if (knownTonnes + 1e-9 < minimum) errors.push(`The minimum for ${details.transport === 'Tailor' ? 'tailor dispatch' : 'a customer order'} is ${minimum} tonnes. Your listed products total ${formatWeight(knownTonnes)} tonnes. Add or update products to continue.`);
  return errors;
}
export function validateFiles(files) {
  if (files.length > MAX_FILES) return [`Choose up to ${MAX_FILES} files.`];
  return files.flatMap(file => {
    const errors = [];
    if (!/\.(pdf|png|jpe?g|xlsx|csv)$/i.test(file.name)) errors.push(`${file.name}: choose a PDF, PNG, JPG, XLSX or CSV file.`);
    if (file.size > MAX_FILE_BYTES) errors.push(`${file.name}: the maximum size is 10 MB per file.`);
    if (file.size === 0) errors.push(`${file.name}: this file is empty.`);
    return errors;
  });
}
export function createReference() {
  const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  return `DS-${date}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
}
export function buildMessage({ items, details, files = [], reference }) {
  const { knownTonnes, needsEstimate } = orderWeight(items);
  const lines = [`Hello Deepa Steel, I would like a quotation.`, `Draft reference: ${reference}`, '', 'MATERIAL REQUIREMENTS'];
  items.forEach((item, index) => lines.push(`${index + 1}. ${categoryName(item.category)} — ${item.quantity} ${item.unit}`, itemSpecs(item)));
  lines.push('', needsEstimate ? `Estimated total: ${details.estimatedTonnes} tonnes (customer estimate; please verify).` : `Total listed weight: ${formatWeight(knownTonnes)} tonnes.`, `Dispatch: ${details.transport}`, '', 'CUSTOMER & DELIVERY', `Name: ${details.name}`);
  if (details.company) lines.push(`Company: ${details.company}`);
  lines.push(`Preferred reply: ${details.reply}`, details.reply === 'Email' ? `Email: ${details.email}` : `Phone: ${details.phone}`, `Delivery: ${details.location}${details.pincode ? ` — ${details.pincode}` : ''}`);
  if (details.purpose) lines.push(`Requirement: ${details.purpose}`);
  if (details.date) lines.push(`Preferred delivery date: ${details.date} (subject to confirmation)`);
  if (details.notes) lines.push(`Additional requirements: ${details.notes}`);
  if (files.length) lines.push('', 'FILES TO ATTACH SEPARATELY IN WHATSAPP', ...files.map(file => `• ${file.name}`));
  lines.push('', 'Please confirm availability, pricing, freight, payment terms and delivery timing. This is an enquiry, not an accepted order.');
  return lines.join('\n');
}
export function whatsappHandoff(message, reference) {
  const base = `https://wa.me/${BUSINESS.phone}?text=`;
  const full = base + encodeURIComponent(message);
  // Keep a conservative link size for different mobile apps. Full details are never silently truncated.
  const needsCopy = full.length > 1800;
  const text = needsCopy ? `Hello Deepa Steel, I have a quotation enquiry. Draft reference: ${reference}. I will paste my complete material list and delivery details in this conversation.` : message;
  return { url: base + encodeURIComponent(text), needsCopy };
}
