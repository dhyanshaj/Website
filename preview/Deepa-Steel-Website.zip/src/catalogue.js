import { CATALOG } from './enquiry.js';

const illustration = id => {
  const defs = `<defs><linearGradient id="metal-${id}" x2="1" y2="1"><stop stop-color="#a6b0a8"/><stop offset="1" stop-color="#43594a"/></linearGradient></defs>`;
  let body = '';
  if (id === 'structural') body = `<path d="m55 95 90-66 65 15-90 66z" fill="#87998b"/><path d="m120 110 90-66v15l-90 66z" fill="#435c49"/><path d="m80 111 90-66v42l-90 66z" fill="#516d56"/><path d="m55 145 90-66 65 15-90 66z" fill="#899b8d"/><path d="m55 95 65 15v15l-25-6v29l25 6v15l-65-15v-15l25 6v-29l-25-6z" fill="url(#metal-${id})"/>`;
  if (id === 'plates') body = [0, 1, 2, 3].map(i => `<g transform="translate(0 ${i * -10})"><path d="m35 115 105-60 90 30-105 60z" fill="#9aab9a"/><path d="m35 115 90 30v8l-90-30z" fill="#6b816e"/><path d="m125 145 105-60v8l-105 60z" fill="#405d49"/></g>`).join('');
  if (id === 'tmt' || id === 'rounds') body = [0, 1, 2, 3, 4].map(i => `<g transform="translate(${i * 23} ${i * 6})"><path d="m37 104 100-80c15-8 26 4 14 14L51 119z" fill="url(#metal-${id})"/><ellipse cx="43" cy="111" rx="10" ry="9" fill="#728875" stroke="#afbaae"/>${id === 'tmt' ? [0, 1, 2, 3, 4, 5, 6].map(j => `<path d="m${53 + j * 12} ${92 - j * 9} 12 10" stroke="#bbcab7" stroke-width="2"/>`).join('') : ''}</g>`).join('');
  if (id === 'pipes') body = `<path d="m45 100 100-70c22-9 48 18 31 34l-99 69z" fill="url(#metal-${id})"/><ellipse cx="61" cy="116" rx="24" ry="20" fill="#8f9f8c"/><ellipse cx="61" cy="116" rx="17" ry="13" fill="#354d3d"/><path d="m115 105 83-62 40 13-83 62z" fill="#9aab98"/><path d="m155 118 83-62v38l-83 62z" fill="#47624b"/><path d="m115 105 40 13v38l-40-13z" fill="#899d86"/><path d="m122 114 26 9v24l-26-9z" fill="#344d39"/>`;
  return `<svg viewBox="0 0 270 185" aria-hidden="true">${defs}${body}</svg>`;
};

export const renderCatalogue = () => CATALOG.map((category, index) => `<article class="product-card"><div class="product-illustration"><span class="product-index">0${index + 1} / MATERIALS</span>${illustration(category.id)}</div><div class="product-content"><h3>${category.name}</h3><p>${category.short}</p><div class="product-bottom"><span class="product-spec">${category.spec}</span><button class="product-add" data-enquire data-category="${category.id}" aria-label="Add ${category.name.toLowerCase()} to enquiry"><svg class="arrow-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M6 18 18 6M6 6h12v12"/></svg></button></div></div></article>`).join('');
