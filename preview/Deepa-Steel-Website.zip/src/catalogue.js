import { CATALOG } from './enquiry.js';

export const PRODUCT_IMAGES = {
  structural: { src: './public/products/structural.jpg', width: 1000, height: 513, fit: 'contain', alt: 'Representative illustration of steel beams, channels, angles and hollow sections' },
  plates: { src: './public/products/plates.jpg', width: 1000, height: 667, fit: 'cover', alt: 'Representative photograph of stacked steel plates' },
  tmt: { src: './public/products/tmt.png', width: 500, height: 500, fit: 'contain', alt: 'Representative image of ribbed reinforcing bars' },
  rounds: { src: './public/products/rounds.webp', width: 1920, height: 550, fit: 'cover', alt: 'Representative photograph of bundled round steel bars with painted ends' },
  pipes: { src: './public/products/pipes.jpg', width: 2048, height: 1365, fit: 'cover', alt: 'Representative image of round, square and rectangular hollow pipes' },
};

export const renderCatalogue = () => CATALOG.map((category, index) => {
  const photo = PRODUCT_IMAGES[category.id];
  return `<article class="product-card"><div class="product-photo"><span class="product-index">0${index + 1} / MATERIALS</span><img class="product-image ${photo.fit}" src="${photo.src}" alt="${photo.alt}" width="${photo.width}" height="${photo.height}" loading="lazy" decoding="async"></div><div class="product-content"><h3>${category.name}</h3><p>${category.short}</p><div class="product-bottom"><span class="product-spec">${category.spec}</span><button class="product-add" data-enquire data-category="${category.id}" aria-label="Add ${category.name.toLowerCase()} to enquiry"><svg class="arrow-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M6 18 18 6M6 6h12v12"/></svg></button></div></div></article>`;
}).join('');
