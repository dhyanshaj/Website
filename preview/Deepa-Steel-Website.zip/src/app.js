import { renderCatalogue } from './catalogue.js';
import { BUSINESS, CATALOG, SECTIONS, MAX_ITEMS, escapeHTML as esc, categoryName, validateItem, itemSpecs, orderWeight, formatWeight, validateDetails, validateFiles, createReference, buildMessage, whatsappHandoff } from './enquiry.js';

const $ = selector => document.querySelector(selector);
const state = {
  step: 0, items: [], draft: { category: 'structural', unit: 'tonnes', quantity: '', assistance: false }, editing: null,
  details: { name: '', company: '', reply: 'WhatsApp', phone: '', email: '', location: '', pincode: '', transport: 'Truck', estimatedTonnes: '', notes: '', purpose: 'One-time requirement', date: '' },
  files: [], reference: '', handoffUntil: 0,
};
let returnFocus;
const dialog = $('#enquiry-dialog');
// Keep Tab/Shift+Tab within the visible controls, including at the browser-chrome boundary.
document.querySelectorAll('dialog').forEach(modal => modal.addEventListener('keydown', event => {
  if (event.key !== 'Tab') return;
  const controls = [...modal.querySelectorAll('button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), summary, [tabindex="0"]')].filter(element => element.getClientRects().length > 0);
  const first = controls[0], last = controls.at(-1);
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
}));
if (!$('#product-grid').children.length) $('#product-grid').innerHTML = renderCatalogue();
$('#year').textContent = new Date().getFullYear();
const menu = $('.menu-toggle');
menu.addEventListener('click', () => {
  const expanded = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(expanded));
  menu.setAttribute('aria-label', expanded ? 'Close navigation' : 'Open navigation');
  $('#navigation').classList.toggle('is-open', expanded);
});
function closeMenu() { menu.setAttribute('aria-expanded', 'false'); menu.setAttribute('aria-label', 'Open navigation'); $('#navigation').classList.remove('is-open'); }
document.querySelectorAll('#navigation a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
function unlockPage() { if (!document.querySelector('dialog[open]')) document.body.classList.remove('modal-open'); }
dialog.addEventListener('close', () => { unlockPage(); returnFocus?.focus(); });
$('#enquiry-close').addEventListener('click', () => dialog.close());
$('#privacy-open').addEventListener('click', () => { $('#privacy-dialog').showModal(); document.body.classList.add('modal-open'); });
$('#privacy-close').addEventListener('click', () => $('#privacy-dialog').close());
$('#privacy-dialog').addEventListener('close', unlockPage);
document.querySelectorAll('[data-enquire]').forEach(button => button.addEventListener('click', () => {
  returnFocus = button;
  closeMenu();
  if (button.dataset.category) { state.draft = { category: button.dataset.category, unit: 'tonnes', quantity: '', assistance: false }; state.editing = null; state.step = 0; }
  if (button.dataset.purpose) state.details.purpose = button.dataset.purpose;
  if (!state.reference) state.reference = createReference();
  render(); dialog.showModal(); document.body.classList.add('modal-open');
}));
function alertErrors(id, errors) {
  const element = $(id); element.textContent = errors.join('\n');
  if (errors.length) { element.tabIndex = -1; element.focus(); element.scrollIntoView({ block: 'nearest' }); }
}
function field(name, label, options = {}) {
  const { value = '', type = 'text', required = false, min, max, step, hint = '', placeholder = '', autocomplete = '', maxLength = 120, extra = '' } = options;
  return `<label class="field"><span>${label}</span><input name="${name}" type="${type}" value="${esc(value)}" ${required ? 'required' : ''} ${min != null ? `min="${min}"` : ''} ${max != null ? `max="${max}"` : ''} ${step != null ? `step="${step}"` : ''} maxlength="${maxLength}" ${placeholder ? `placeholder="${esc(placeholder)}"` : ''} ${autocomplete ? `autocomplete="${autocomplete}"` : ''} ${extra}>${hint ? `<small>${hint}</small>` : ''}</label>`;
}
function select(name, label, values, value, hint = '') {
  return `<label class="field"><span>${label}</span><select name="${name}">${values.map(option => { const [key, title] = Array.isArray(option) ? option : [option, option]; return `<option value="${esc(key)}" ${key === value ? 'selected' : ''}>${esc(title)}</option>`; }).join('')}</select>${hint ? `<small>${hint}</small>` : ''}</label>`;
}
function getItem() {
  const form = $('#material-form');
  if (!form) return state.draft;
  const item = Object.fromEntries(new FormData(form));
  item.assistance = Boolean(form.elements.assistance.checked);
  for (const key in item) if (typeof item[key] === 'string') item[key] = item[key].trim();
  return item;
}
function getDetails() {
  if (!$('#details-form')) return;
  const data = Object.fromEntries(new FormData($('#details-form')));
  delete data.attachments;
  state.details = { ...state.details, ...data };
  for (const key in state.details) if (typeof state.details[key] === 'string') state.details[key] = state.details[key].trim();
}
function itemCard(item, index, editable = true) {
  return `<article class="line-item"><h4>${index + 1}. ${categoryName(item.category)}</h4><p>${esc(itemSpecs(item))}</p><p class="item-quantity">${esc(item.quantity)} ${esc(item.unit)}</p>${editable ? `<div class="line-actions"><button type="button" data-edit="${index}" aria-label="Edit product ${index + 1}">Edit</button><button type="button" data-remove="${index}" aria-label="Remove product ${index + 1}">Remove</button></div>` : ''}</article>`;
}
function renderMaterials() {
  const item = state.draft;
  const numeric = (name, label, min = 0.001, max) => field(name, label, { value: item[name], type: 'number', min, max, step: 'any', required: !item.assistance });
  let specifications = '';
  if (item.category === 'structural') specifications += select('section', 'Section', [['', 'Choose a section'], ...SECTIONS], item.section) + field('designation', 'Designation or dimensions (mm)', { value: item.designation, placeholder: 'As specified in your material list', required: !item.assistance, maxLength: 80 });
  if (item.category === 'plates') specifications += numeric('thickness', 'Thickness (3–50 mm)', 3, 50) + numeric('width', 'Width (mm)');
  if (item.category === 'tmt') specifications += numeric('diameter', 'Required diameter (mm)');
  if (item.category === 'rounds') specifications += numeric('diameter', 'Diameter (6–100 mm)', 6, 100);
  if (item.category === 'pipes') {
    specifications += select('shape', 'Pipe shape', [['', 'Choose a shape'], ['round', 'Round'], ['square', 'Square'], ['rectangular', 'Rectangular']], item.shape);
    if (item.shape === 'round') specifications += numeric('diameter', 'Outer diameter (mm)');
    if (['square', 'rectangular'].includes(item.shape)) specifications += numeric('width', 'Outer width (mm)');
    if (item.shape === 'rectangular') specifications += numeric('height', 'Outer height (mm)');
    specifications += numeric('thickness', 'Wall thickness (mm)');
  }
  specifications += numeric('length', 'Required length (mm)') + field('grade', 'Grade, if known', { value: item.grade, placeholder: 'Optional', maxLength: 50 });
  const weight = orderWeight(state.items);
  $('#wizard-content').innerHTML = `<p class="wizard-intro">Add each product to your enquiry. All dimensions are in millimetres (mm). Sizes and grades are requested specifications, subject to availability.</p><div class="material-layout"><form class="material-form" id="material-form"><h3>${state.editing === null ? 'Add a product' : `Edit product ${state.editing + 1}`}</h3>${select('category', 'Product category', CATALOG.map(c => [c.id, c.name]), item.category)}<label class="checkbox-label"><input name="assistance" type="checkbox" ${item.assistance ? 'checked' : ''}> I need help with the specifications</label>${item.assistance ? `<label class="field"><span>Describe your requirement</span><textarea name="description" required maxlength="500" placeholder="Tell us what material you are looking for. We’ll help clarify the details.">${esc(item.description || '')}</textarea></label>` : ''}<div class="field-grid">${specifications}${field('quantity', 'Quantity', { value: item.quantity, type: 'number', min: item.unit === 'pieces' ? 1 : 0.001, max: 100000000, step: item.unit === 'pieces' ? 1 : 'any', required: true })}${select('unit', 'Quantity unit', [['tonnes', 'Tonnes'], ['kg', 'Kilograms (kg)'], ['pieces', 'Pieces']], item.unit)}</div><div id="item-error" class="error-message" role="alert"></div><button type="submit" class="button button-dark">${state.editing === null ? '+ Add to enquiry' : 'Save product changes'}</button>${state.editing !== null ? '<button type="button" class="plain-button" id="cancel-edit">Cancel edit</button>' : ''}</form><aside class="enquiry-list" aria-label="Selected materials"><h3>Your materials <span class="optional">(${state.items.length}/${MAX_ITEMS})</span></h3>${state.items.length ? state.items.map((entry, index) => itemCard(entry, index)).join('') : '<div class="empty-list">Your project list starts here.<br>Add a product using the form, then add any other materials you need.</div>'}${state.items.length ? `<p class="list-total">Listed weight: ${formatWeight(weight.knownTonnes)} tonnes${weight.needsEstimate ? ' + items in pieces' : ''}</p>` : ''}<div class="minimum-note">Minimum order: <strong>10 tonnes</strong>. Mix products to meet the minimum. Tailor dispatch requires at least <strong>40 tonnes</strong>. Quantities in pieces need your total weight estimate at the next step.</div></aside></div><div id="materials-error" class="error-message" role="alert"></div><div class="wizard-actions"><p class="form-help">No prices or stock are assumed. An owner will prepare your quotation after reviewing the enquiry.</p><button class="button button-gold" id="materials-next" ${!state.items.length ? 'disabled' : ''}>Your details <span aria-hidden="true">→</span></button></div>`;
  $('#material-form').addEventListener('input', () => { state.draft = getItem(); });
  $('#material-form').addEventListener('change', event => {
    state.draft = getItem();
    const name = event.target.name;
    if (name === 'category') {
      const { category, quantity, unit, assistance, description, grade } = state.draft;
      state.draft = { category, quantity, unit, assistance, description, grade };
    }
    if (name === 'shape') for (const key of ['width', 'height', 'diameter']) delete state.draft[key];
    if (['category', 'shape', 'assistance', 'unit'].includes(name)) { renderMaterials(); $(`#material-form [name="${name}"]`).focus(); }
  });
  $('#material-form').addEventListener('submit', event => {
    event.preventDefault();
    const entry = getItem();
    const errors = validateItem(entry);
    if (state.items.length >= MAX_ITEMS && state.editing === null) errors.push(`You can add up to ${MAX_ITEMS} products. For a longer list, attach your BOQ in WhatsApp.`);
    if (errors.length) { alertErrors('#item-error', errors); return; }
    if (state.editing !== null) state.items[state.editing] = entry; else state.items.push(entry);
    state.editing = null;
    state.draft = { category: entry.category, unit: 'tonnes', quantity: '', assistance: false };
    renderMaterials();
    $('.enquiry-list h3').tabIndex = -1; $('.enquiry-list h3').focus();
  });
  document.querySelectorAll('[data-edit]').forEach(button => button.addEventListener('click', () => { state.editing = Number(button.dataset.edit); state.draft = { ...state.items[state.editing] }; renderMaterials(); $('#material-form [name="category"]').focus(); }));
  document.querySelectorAll('[data-remove]').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.remove); state.items.splice(index, 1);
    if (state.editing === index) { state.editing = null; state.draft = { category: 'structural', quantity: '', unit: 'tonnes' }; }
    else if (state.editing > index) state.editing--;
    renderMaterials(); $('#materials-next').focus();
  }));
  $('#cancel-edit')?.addEventListener('click', () => { state.editing = null; state.draft = { category: 'structural', quantity: '', unit: 'tonnes' }; renderMaterials(); });
  $('#materials-next').addEventListener('click', () => {
    if (state.editing !== null || state.draft.quantity || state.draft.description) { alertErrors('#materials-error', ['You have a product being edited. Add or save it before continuing.']); return; }
    state.step = 1; render();
  });
}
function renderDetails() {
  const d = state.details;
  const weight = orderWeight(state.items);
  const minimum = d.transport === 'Tailor' ? 40 : 10;
  $('#wizard-content').innerHTML = `<form class="details-form" id="details-form"><h3>A few details for your quotation</h3><p class="form-subtitle">Tell us where the material is needed and how you’d like our business owner to reply.</p><div class="field-grid">${field('name', 'Your name', { value: d.name, required: true, autocomplete: 'name', maxLength: 80 })}${field('company', 'Company name (optional)', { value: d.company, autocomplete: 'organization', maxLength: 120 })}${select('reply', 'Preferred reply', ['WhatsApp', 'Phone call', 'Email'], d.reply)}${d.reply === 'Email' ? field('email', 'Email address', { type: 'email', value: d.email, required: true, autocomplete: 'email', maxLength: 150 }) : field('phone', 'Phone / WhatsApp number', { type: 'tel', value: d.phone, required: true, autocomplete: 'tel', placeholder: '+91', maxLength: 25 })}</div><div class="field-section"><h3>Delivery & order details</h3><div class="field-grid">${field('location', 'Delivery city and state', { value: d.location, required: true, placeholder: 'e.g. Pune, Maharashtra', maxLength: 150 })}${field('pincode', 'Delivery PIN code (optional)', { value: d.pincode, maxLength: 6, extra: 'inputmode="numeric" pattern="[0-9]{6}"', autocomplete: 'postal-code' })}${select('transport', 'Dispatch option', [['Truck', 'Truck — minimum 10 tonnes'], ['Tailor', 'Tailor — minimum 40 tonnes'], ['Help me choose', 'Help me choose — order minimum 10 tonnes']], d.transport)}${select('purpose', 'Type of requirement', ['One-time requirement', 'Repeat / project supply', 'Vendor registration discussion'], d.purpose)}${weight.needsEstimate ? field('estimatedTonnes', 'Estimated total order weight (tonnes)', { value: d.estimatedTonnes, type: 'number', min: minimum, step: 'any', required: true, hint: 'Your estimate for the entire order, including pieces. We do not convert pieces to weight. The owner will verify the total.' }) : ''}${field('date', 'Preferred delivery date (optional)', { type: 'date', value: d.date, hint: 'A preference for the quotation, not a confirmed delivery date.' })}</div><div class="minimum-note">${weight.needsEstimate ? `${formatWeight(weight.knownTonnes)} tonnes entered by weight, plus quantities in pieces.` : `Your listed products total <strong>${formatWeight(weight.knownTonnes)} tonnes</strong>.`} Minimum for this option: <strong>${minimum} tonnes</strong>. You can go back to add or edit products.</div></div><div class="field-section"><label class="field"><span>Special requirements (optional)</span><textarea name="notes" maxlength="1000" placeholder="Share any specifications, schedule preferences or information needed for your quotation.">${esc(d.notes)}</textarea></label><label class="field"><span>Drawings or material lists (optional)</span><input type="file" name="attachments" multiple accept=".pdf,.png,.jpg,.jpeg,.xlsx,.csv" aria-describedby="file-help"><small id="file-help">Up to 3 files, 10 MB each. PDF, PNG, JPG, XLSX or CSV. Files stay on your device. Attach them yourself in WhatsApp after opening the conversation; this website does not upload or send files.</small></label><div id="file-error" class="error-message" role="alert"></div><ul class="attachment-list" id="attachment-list"></ul></div><div id="details-error" class="error-message" role="alert"></div><div class="wizard-actions"><button class="plain-button" type="button" id="details-back">← Edit materials</button><button class="button button-gold" type="submit">Review enquiry <span aria-hidden="true">→</span></button></div></form>`;
  renderFiles();
  $('#details-form').addEventListener('input', event => { if (event.target.type !== 'file') getDetails(); });
  $('#details-form').addEventListener('change', event => {
    if (event.target.type === 'file') return;
    getDetails();
    if (['reply', 'transport'].includes(event.target.name)) { const name = event.target.name; renderDetails(); $(`#details-form [name="${name}"]`).focus(); }
  });
  $('#details-form [name="attachments"]').addEventListener('change', event => {
    const files = Array.from(event.target.files);
    const errors = validateFiles(files);
    event.target.value = '';
    alertErrors('#file-error', errors);
    if (errors.length) return;
    state.files = files.map(file => ({ name: file.name, size: file.size }));
    renderFiles();
  });
  $('#details-back').addEventListener('click', () => { getDetails(); state.step = 0; render(); });
  $('#details-form').addEventListener('submit', event => {
    event.preventDefault(); getDetails();
    const errors = validateDetails(state.details, state.items);
    if (errors.length) { alertErrors('#details-error', errors); return; }
    state.step = 2; render();
  });
}
function renderFiles() {
  $('#attachment-list').innerHTML = state.files.map((file, index) => `<li><span>${esc(file.name)} · ${(file.size / 1024).toFixed(0)} KB · attach in WhatsApp</span><button type="button" data-file-remove="${index}" aria-label="Remove ${esc(file.name)}">Remove</button></li>`).join('');
  document.querySelectorAll('[data-file-remove]').forEach(button => button.addEventListener('click', () => { state.files.splice(Number(button.dataset.fileRemove), 1); renderFiles(); }));
}
function renderReview() {
  const d = state.details;
  const message = buildMessage(state);
  const handoff = whatsappHandoff(message, state.reference);
  const weight = orderWeight(state.items);
  $('#wizard-content').innerHTML = `<div class="review-heading"><h3>Check your enquiry before sending</h3><span class="draft-ref">${esc(state.reference)} · draft reference</span></div><div class="review-grid"><section class="review-box" aria-label="Review materials"><h4>Your material list</h4>${state.items.map((item, index) => itemCard(item, index, false)).join('')}<p><strong>${weight.needsEstimate ? `Estimated total: ${esc(d.estimatedTonnes)} tonnes` : `Listed total: ${formatWeight(weight.knownTonnes)} tonnes`}</strong></p>${weight.needsEstimate ? '<p>Customer estimate; weight will be verified by the owner.</p>' : ''}<button class="plain-button" id="review-materials">Edit materials</button></section><section class="review-box" aria-label="Review contact and delivery"><h4>Contact & delivery</h4><p><strong>${esc(d.name)}</strong>${d.company ? `<br>${esc(d.company)}` : ''}<br>${esc(d.reply)}: ${esc(d.reply === 'Email' ? d.email : d.phone)}</p><p>Delivery: ${esc(d.location)}${d.pincode ? `, ${esc(d.pincode)}` : ''}<br>Dispatch: ${esc(d.transport)}<br>${esc(d.purpose)}</p>${d.date ? `<p>Preferred date: ${esc(d.date)} (to be confirmed)</p>` : ''}${d.notes ? `<p>Special requirements: ${esc(d.notes)}</p>` : ''}${state.files.length ? `<p><strong>Attach separately in WhatsApp:</strong><br>${state.files.map(file => esc(file.name)).join('<br>')}</p>` : ''}<button class="plain-button" id="review-details">Edit your details</button></section></div><div class="notice"><strong>One more step: press Send in WhatsApp.</strong>This website prepares your enquiry. Opening WhatsApp does not send it. Your quotation includes transport charges. An owner will confirm pricing, availability, payment terms and delivery timing. An enquiry is not an accepted order.${state.files.length ? ' Remember to attach your selected files in the WhatsApp conversation.' : ''}</div>${handoff.needsCopy ? '<div class="notice"><strong>Your enquiry is longer than our mobile link limit.</strong>First copy the full enquiry below. Then open WhatsApp, paste it into the conversation and press Send. The WhatsApp link contains only your draft reference and introduction.</div>' : ''}<div class="handoff-actions"><a class="button button-gold" id="whatsapp-send" href="${esc(handoff.url)}" target="_blank" rel="noopener noreferrer" aria-label="Open WhatsApp to send your enquiry">Open WhatsApp <span aria-hidden="true"><svg class="arrow-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M6 18 18 6M6 6h12v12"/></svg></span></a><button class="button button-outline" id="copy-enquiry">Copy ${handoff.needsCopy ? 'full enquiry' : 'enquiry'}</button><button class="button button-outline" id="download-enquiry">Download enquiry</button></div><p class="status-message" role="status" id="handoff-status"></p><p class="handoff-note">If WhatsApp does not open, copy or download your enquiry and email it to <a href="mailto:${BUSINESS.email}">${BUSINESS.email}</a>, or call <a href="tel:+${BUSINESS.phone}">9322758844</a> or <a href="tel:+${BUSINESS.secondPhone}">9322658844</a>. To avoid duplicates, send through one channel and reuse this draft reference when following up.</p><details class="review-message"><summary>View the complete message or copy it manually</summary><label class="field"><span>Enquiry message</span><textarea id="message-text" readonly>${esc(message)}</textarea></label></details><div class="wizard-actions"><button class="plain-button" id="review-back">← Back to your details</button><p class="form-help">No payment is collected on this website.</p></div>`;
  $('#review-materials').addEventListener('click', () => { state.step = 0; render(); });
  for (const selector of ['#review-details', '#review-back']) $(selector).addEventListener('click', () => { state.step = 1; render(); });
  $('#whatsapp-send').addEventListener('click', event => {
    if (Date.now() < state.handoffUntil) { event.preventDefault(); return; }
    state.handoffUntil = Date.now() + 3000;
    event.currentTarget.setAttribute('aria-disabled', 'true');
    $('#handoff-status').textContent = `Continue in WhatsApp and press Send${handoff.needsCopy ? ' after pasting your full enquiry' : ''}. This page cannot verify delivery. ${state.files.length ? 'Attach your selected files there.' : ''}`;
    setTimeout(() => $('#whatsapp-send')?.removeAttribute('aria-disabled'), 3000);
  });
  $('#copy-enquiry').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(message);
      $('#handoff-status').textContent = 'Enquiry copied. Paste it into your WhatsApp conversation or email, then send it.';
    } catch {
      $('.review-message').open = true; $('#message-text').focus(); $('#message-text').select();
      $('#handoff-status').textContent = 'Automatic copying is unavailable. The full message is selected below. Use your device’s Copy command, or download the enquiry.';
    }
  });
  $('#download-enquiry').addEventListener('click', () => {
    const url = URL.createObjectURL(new Blob([message], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = `${state.reference}.txt`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    $('#handoff-status').textContent = 'The enquiry download was requested. Check your downloads, then share it with Deepa Steel. Downloading does not send an enquiry.';
  });
}
function render() {
  document.querySelectorAll('[data-step]').forEach(element => { if (Number(element.dataset.step) === state.step) element.setAttribute('aria-current', 'step'); else element.removeAttribute('aria-current'); });
  [renderMaterials, renderDetails, renderReview][state.step]();
  dialog.scrollTop = 0;
  if (dialog.open) { $('#enquiry-title').tabIndex = -1; $('#enquiry-title').focus(); }
}
